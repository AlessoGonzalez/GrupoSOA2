<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Servicios</title>
    <link rel="stylesheet" type="text/css" href="jquery-easyui-1.10.17/themes/default/easyui.css">
    <link rel="stylesheet" type="text/css" href="jquery-easyui-1.10.17/themes/icon.css">
    <link rel="stylesheet" type="text/css" href="jquery-easyui-1.10.17/themes/color.css">
    <script type="text/javascript" src="jquery-easyui-1.10.17/jquery.min.js"></script>
    <script type="text/javascript" src="jquery-easyui-1.10.17/jquery.easyui.min.js"></script>
</head>
<body>
    <h2>UTA</h2>
    <p>UTA</p>
    
    <table id="dg" title="Estudiantes" class="easyui-datagrid" style="width:700px;height:250px"
            url="http://localhost/Quinto/api.php"
            toolbar="#toolbar" pagination="true"
            rownumbers="true" fitColumns="true" singleSelect="true" method="get">
        <thead>
            <tr>
                <th field="Cedula" width="50">Cedula</th>
                <th field="Nombre" width="50">Nombre</th>
                <th field="Apellido" width="50">Apellido</th>
                <th field="Direccion" width="50">Direccion</th>
                <th field="Telefono" width="50">Telefono</th>
            </tr>
        </thead>
    </table>
    <div id="toolbar">
        <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-add" plain="true" onclick="newUser()">Nuevo Estudiante</a>
        <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-edit" plain="true" onclick="editUser()">Editar Estudiante</a>
        <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-remove" plain="true" onclick="eliminar()">Eliminar Estudiante</a>
    </div>
    
    <div id="dlg" class="easyui-dialog" style="width:400px" data-options="closed:true,modal:true,border:'thin',buttons:'#dlg-buttons'">
        <form id="fm" method="post" novalidate style="margin:0;padding:20px 50px">
            <h3>Estudiante</h3>
            <div style="margin-bottom:10px">
                <input name="Cedula" class="easyui-textbox" required="true" label="Cedula" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input name="Nombre" class="easyui-textbox" required="true" label="Nombre" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input name="Apellido" class="easyui-textbox" required="true" label="Apellido" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input name="Direccion" class="easyui-textbox" required="true" label="Direccion" style="width:100%">
            </div>
            <div style="margin-bottom:10px">
                <input name="Telefono" class="easyui-textbox" required="true" label="Telefono" style="width:100%">
            </div>
        </form>
    </div>
    <div id="dlg-buttons">
        <a href="javascript:void(0)" class="easyui-linkbutton c6" iconCls="icon-ok" onclick="saveUser()" style="width:90px">Save</a>
        <a href="javascript:void(0)" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript:$('#dlg').dialog('close')" style="width:90px">Cancel</a>
    </div>
    <script type="text/javascript">
        var url;
        function newUser(){
            $('#dlg').dialog('open').dialog('center').dialog('setTitle','Nuevo Estudiante');
            $('#fm').form('clear');
            url = 'http://localhost/Quinto/api.php';
        }
        function editUser(){
            var row = $('#dg').datagrid('getSelected');
            if (row){
                $('#dlg').dialog('open').dialog('center').dialog('setTitle','Editar Estudiante');
                $('#fm').form('load',row);
                url = 'http://localhost/Quinto/api.php'+row.id;
            }
        }
        function saveUser(){
            $('#fm').form('submit',{
                url: url,
                iframe: false,
                onSubmit: function(){
                    return $(this).form('validate');
                },
                success: function(result){
                    var result = eval('('+result+')');
                    if (result.errorMsg){
                        $.messager.show({
                            title: 'Error',
                            msg: result.errorMsg
                        });
                    } else {
                        $('#dlg').dialog('close');        // close the dialog
                        $('#dg').datagrid('reload');    // reload the user data
                    }
                }
            });
        }
        function eliminar(){
            var row = $('#dg').datagrid('getSelected');
            if (row){
                $.messager.confirm('Confirm','Are you sure you want to destroy this user?',function(r){
                    if (r){
                        $.post('destroy_user.php',{id:row.id},function(result){
                            if (result.success){
                                $('#dg').datagrid('reload');    // reload the user data
                            } else {
                                $.messager.show({    // show error message
                                    title: 'Error',
                                    msg: result.errorMsg
                                });
                            }
                        },'json');
                    }
                });
            }
        }
    </script>
</body>
</html>