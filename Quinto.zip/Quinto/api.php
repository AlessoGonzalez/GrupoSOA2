<?php
//El metodo server me devuelve en donde estoy si post , delete o put 
$opc=$_SERVER["REQUEST_METHOD"];
include_once 'seleccionar.php';
include_once 'guardar.php';
include_once 'delete.php';
//include_once 'actualizar.php';

switch($opc){
    case "GET":
    //$resultado="Tu estas en un get";
    CRUD::ObtenerEstudiantes();
    //echo($resultado);
    break;
    case "POST":
        CRUDG::GuardarEstudiante();
        break;
    case "DELETE":  
        $var=$_GET["var"];
        CRUDE::EliminarEstudiante($var);
        break;
    case "PUT":  
        $var=$_GET["var"];
        CRUDE::ActualizarEstudiante($var);
        break;
}
?>