<?php
include_once 'conexion.php';
Class CRUDG{
    public static function GuardarEstudiante(){
        $cedula = $_POST['Cedula'];
        $nombre = $_POST["Nombre"];
        $apellido = $_POST["Apellido"];
        $direccion = $_POST["Direccion"];
        $telefono = $_POST["Telefono"];
        
        $objeto = new Conexion();
        $conectar = $objeto->Conectar();
        
        $insertsql = "INSERT INTO estudiante (Cedula, Nombre, Apellido, Direccion, Telefono) VALUES ('$cedula', '$nombre', '$apellido', '$direccion', '$telefono')";
        
        $resultado = $conectar->prepare($insertsql);
        $resultado->execute();
        //primera forma
        //echo json_encode($_POST);
        //segunda forma
        //$datos = array(
            //"cedula" => $cedula,
            //"nombre" => $nombre,
            //"apellido" => $apellido,
            //"direccion" => $direccion,
            //"telefono" => $telefono,
        //);
        //echo json_encode($datos);
        $conectar->commit();
   }
}

?>
