/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.daniel.java;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author ASUS
 */
public class Api {

    ArrayList<Estudiante> array = new ArrayList<>();

    public ArrayList<Estudiante> GET() {
        try {
            array.clear();
            URL url = new URL("http://localhost/Quinto/api.php");
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            http.setRequestMethod("GET");
            http.connect();

            int response = http.getResponseCode();
            if (response != 200) {
                System.out.println("ERROR");
            } else {
                StringBuilder datos = new StringBuilder();
                Scanner sc = new Scanner(http.getInputStream());
                while (sc.hasNext()) {
                    datos.append(sc.nextLine());
                }
                sc.close();
                JSONArray json = new JSONArray(datos.toString());

                for (int i = 0; i < json.length(); i++) {
                    JSONObject objeto = json.getJSONObject(i);

                    String cedula = objeto.getString("cedula");
                    String nombre = objeto.getString("nombre");
                    String apellido = objeto.getString("apellido");
                    String direccion = objeto.getString("direccion");
                    String telefono = objeto.getString("telefono");
                    Estudiante est = new Estudiante(cedula, nombre, apellido, direccion, telefono);
                    array.add(est);
                }
            }
            http.disconnect();
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
        return array;
    }

    public void POST(String cedula, String nombre, String apellido, String direccion, String telefono) {
        try {
            HttpClient client = HttpClientBuilder.create().build();
            String url = "http://localhost/Quinto/api.php";
            HttpPost post = new HttpPost(url);
            ArrayList<BasicNameValuePair> parametros = new ArrayList<>();
            parametros.add(new BasicNameValuePair("cedula", cedula));
            parametros.add(new BasicNameValuePair("nombre", nombre));
            parametros.add(new BasicNameValuePair("apellido", apellido));
            parametros.add(new BasicNameValuePair("direccion", direccion));
            parametros.add(new BasicNameValuePair("telefono", telefono));
            post.setEntity(new UrlEncodedFormEntity(parametros));
            client.execute(post);
        } catch (Exception e) {
            System.out.println("ERROR");
        }
    }

    public void Actualizar(String cedula, String nombre, String apellido, String direccion, String telefono) {
        try {
            String url = "http://localhost/Quinto/api.php?";
            String parametros = "cedula=" + cedula + "&nombre=" + nombre + "&apellido=" + apellido + "&direccion=" + direccion + "&telefono=" + telefono;
            URL url1 = new URL(url + parametros);
            HttpURLConnection conn = (HttpURLConnection) url1.openConnection();
            conn.setRequestMethod("PUT");
            int respuesta = conn.getResponseCode();
            if (respuesta == 200) {
                JOptionPane.showMessageDialog(null, "OK");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public void Eliminar(String cedula) {
        try {
            String url1 = "http://localhost/Quinto/api.php?";
            URL url = new URL(url1 + "cedula=" + cedula);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            int respuesta = conn.getResponseCode();
            if (respuesta == 200) {
                JOptionPane.showMessageDialog(null, "OK");
            }
        } catch (Exception ex) {
        }
    }

    public DefaultTableModel obtener(javax.swing.JTable Tabla) {
        DefaultTableModel modelo;
        modelo = (DefaultTableModel) Tabla.getModel();
        modelo.setRowCount(0);
        try {
            HttpClient cliente = HttpClientBuilder.create().build();
            HttpGet get = new HttpGet("http://localhost/Quinto/api.php");
            HttpResponse respuesta = cliente.execute(get);
            String info = EntityUtils.toString(respuesta.getEntity());
            JSONArray jsonArray = new JSONArray(info);
            
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String cedula = jsonObject.getString("cedula");
                String nombre = jsonObject.getString("nombre");
                String apellido = jsonObject.getString("apellido");
                String direccion = jsonObject.getString("direccion");
                String telefono = jsonObject.getString("telefono");
                modelo.addRow(new Object[]{cedula, nombre, apellido, direccion, telefono});
            }
            return modelo;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }

    }

//    public void POST(Map<String, String> fromdata) {
//        try {
//            URL url = new URL("http://localhost/Quinto/api.php");
//            HttpURLConnection http = (HttpURLConnection) url.openConnection();
//            http.setRequestMethod("POST");
//            http.connect();
//            http.setDoInput(true);
//            StringBuilder formatdat = new StringBuilder();
//
//            for (Map.Entry<String, String> entrada : fromdata.entrySet()) {
//                if (formatdat.length() != 0) {
//                    formatdat.append('&');
//                    formatdat.append(entrada.getKey());
//                    formatdat.append('=');
//                    formatdat.append(entrada.getValue());
//                }
//            }
//            OutputStream os = http.getOutputStream();
//            OutputStreamWriter writer = new OutputStreamWriter(os);
//            writer.write(formatdat.toString());
//            int respuesta = http.getResponseCode();
//            BufferedReader lector = new BufferedReader(new InputStreamReader(http.getInputStream()));
//            StringBuilder response = new StringBuilder();
//            String line;
//
//            if ((line = lector.readLine()) != null) {
//                response.append(line);
//            }
//            String respuestaDelServidor = response.toString();
//            if (respuesta == 200 && !respuestaDelServidor.isEmpty()) {
//                JOptionPane.showMessageDialog(null, "Solicitud completada");
//            } else {
//                JOptionPane.showMessageDialog(null, "Solicitud no completada");
//            }
//        } catch (Exception ex) {
//
//        }
//    }
}
