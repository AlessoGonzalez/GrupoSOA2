/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ec.daniel.java;

import java.util.Map;


/**
 *
 * @author ASUS
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Api api = new Api();
        System.out.println(api.GET().get(0).getNombre());
        Estudiante est = new Estudiante("1111", "1111", "1111", "1111", "1111");
        Map<String, String> form = Map.of("cedula",est.getCedula(),"nombre",est.getNombre(),"apellido",est.getApellido(),"direccion",est.getDireccion(),"telefono",est.getTelefono());
        //api.POST(form);
    }
    
    
}
